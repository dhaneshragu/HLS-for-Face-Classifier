#pragma once 
#include "./k2c_tensor_include.h"
void face_classifier_c(k2c_tensor* dense_input_input, k2c_tensor* activation_3_output); 
void face_classifier_c_initialize(); 
void face_classifier_c_terminate(); 
