//Numpy array shape [2]
//Min -0.075947023928
//Max 0.075946979225
//Number of zeros 0

#ifndef B19_H_
#define B19_H_

#ifndef __SYNTHESIS__
model_default_t b19[2];
#else
model_default_t b19[2] = {-0.0759470239, 0.0759469792};
#endif

#endif
